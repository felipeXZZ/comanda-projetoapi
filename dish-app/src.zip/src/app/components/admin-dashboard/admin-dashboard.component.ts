import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

// 1. IMPORTA OS DOIS SERVIÇOS
import { PedidoService, PedidoCompleto } from '../../services/pedido.service';
import { Dish, DishService } from '../../services/dish.service'; // <-- IMPORTA O DISH SERVICE

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  // Seção de Pedidos
  pedidos: PedidoCompleto[] = [];
  isLoadingPedidos = true;
  errorPedidos: string | null = null;
  statusList: string[] = [
    'RECEBIDO', 'EM_PREPARO', 'SAIU_PARA_ENTREGA', 'ENTREGUE', 'CANCELADO'
  ];

  // 2. NOVA SEÇÃO DE PRATOS
  dishes: Dish[] = [];
  isLoadingDishes = true;
  errorDishes: string | null = null;

  // 3. INJETA OS DOIS SERVIÇOS
  constructor(
    private pedidoService: PedidoService,
    private dishService: DishService // <-- INJETA O DISH SERVICE
  ) { }

  ngOnInit(): void {
    // 4. CARREGA AS DUAS LISTAS
    this.loadPedidos();
    this.loadDishes();
  }

  loadPedidos(): void {
    this.isLoadingPedidos = true;
    this.errorPedidos = null;
    this.pedidoService.getAllPedidos().subscribe({
      next: (data) => {
        this.pedidos = data.sort((a, b) => b.id - a.id);
        this.isLoadingPedidos = false;
      },
      error: (err) => {
        this.errorPedidos = 'Não foi possível carregar os pedidos.';
        this.isLoadingPedidos = false;
      }
    });
  }

  // 5. NOVA LÓGICA PARA CARREGAR PRATOS
  loadDishes(): void {
    this.isLoadingDishes = true;
    this.errorDishes = null;
    this.dishService.getDishes().subscribe({
      next: (data) => {
        this.dishes = data.sort((a, b) => (a.id || 0) - (b.id || 0));
        this.isLoadingDishes = false;
      },
      error: (err) => {
        this.errorDishes = 'Não foi possível carregar os pratos.';
        this.isLoadingDishes = false;
      }
    });
  }

  // 6. NOVA LÓGICA PARA DELETAR PRATOS
  deleteDish(id: number | undefined): void {
    if (!id) return;
    if (confirm('Tem certeza que deseja deletar este prato?')) {
      this.dishService.deleteDish(id).subscribe({
        next: () => {
          this.dishes = this.dishes.filter(dish => dish.id !== id);
        },
        error: (err) => {
          alert('Erro ao deletar o prato.');
        }
      });
    }
  }

  // (Lógica de onStatusChange continua a mesma)
  onStatusChange(pedidoId: number, event: Event): void {
    const selectElement = event.target as HTMLSelectElement;
    const novoStatus = selectElement.value;
    if (!novoStatus) return;

    this.pedidoService.updatePedidoStatus(pedidoId, novoStatus).subscribe({
      next: (pedidoAtualizado) => {
        const index = this.pedidos.findIndex(p => p.id === pedidoId);
        if (index !== -1) {
          this.pedidos[index].status = pedidoAtualizado.status;
        }
      },
      error: (err) => {
        alert('Erro ao atualizar status. (O bug do @Transactional ainda pode estar aqui se o Eclipse não reiniciou corretamente!)');
      }
    });
  }
}
