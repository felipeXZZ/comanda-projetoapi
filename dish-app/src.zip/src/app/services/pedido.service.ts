import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// --- Interfaces (Modelos de dados para Pedidos) ---

export interface ItemPedido {
  // Nota: enviamos apenas o ID do prato, o backend cuida do resto
  dish: { id: number };
  quantidade: number;
}

export interface Pedido {
  // Dados do cliente
  nomeCliente: string;
  telefoneCliente: string;
  enderecoCliente: string;

  // Lista de itens
  itens: ItemPedido[];
}

export interface PedidoCompleto {
  id: number;
  nomeCliente: string;
  telefoneCliente: string;
  enderecoCliente: string;
  dataCriacao: string; // ou Date
  status: string; // "RECEBIDO", "EM_PREPARO", etc.
  total: number;
  itens: any[]; // Pode ser mais detalhado se quisermos
}


@Injectable({
  providedIn: 'root'
})
export class PedidoService {

  // A URL base da API de Pedidos (que criamos no Java)
  private readonly apiUrl = 'http://localhost:8080/api/pedidos';

  constructor(private http: HttpClient) { }

  // --- MÉTODOS PARA PEDIDO ---

  /**
   * Cria um novo pedido
   * Chama: POST /api/pedidos
   */
  public createPedido(pedidoData: Pedido): Observable<PedidoCompleto> {
    return this.http.post<PedidoCompleto>(this.apiUrl, pedidoData);
  }

  /**
   * Busca um pedido específico pelo ID (para rastreamento)
   * Chama: GET /api/pedidos/{id}
   */
  public getPedidoById(id: number): Observable<PedidoCompleto> {
    return this.http.get<PedidoCompleto>(`${this.apiUrl}/${id}`);
  }

  /**
   * Busca todos os pedidos
   * Chama: GET /api/pedidos
   */
  public getAllPedidos(): Observable<PedidoCompleto[]> {
    return this.http.get<PedidoCompleto[]>(this.apiUrl);
  }

  /**
   * Atualiza o status de um pedido
   * Chama: PATCH /api/pedidos/{id}/status
   */
  public updatePedidoStatus(id: number, novoStatus: string): Observable<PedidoCompleto> {
    const body = { novoStatus: novoStatus };
    return this.http.patch<PedidoCompleto>(`${this.apiUrl}/${id}/status`, body);
  }
}
