import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

// NOSSOS SERVIÇOS
import { Dish, DishService } from '../../services/dish.service';
import { CartService, CartItem } from '../../services/cart.service';

@Component({
  selector: 'app-dish-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink
  ],
  templateUrl: './dish-list.component.html',
  styleUrls: ['./dish-list.component.css']
})
export class DishListComponent implements OnInit {

  dishes: Dish[] = [];
  isLoading = true;
  error: string | null = null;

  public totalItensNoCarrinho$: Observable<number>;
  public totalPrecoCarrinho$: Observable<number>;

  constructor(
    private dishService: DishService,
    private cartService: CartService
  ) {
    this.totalPrecoCarrinho$ = this.cartService.total$;
    this.totalItensNoCarrinho$ = this.cartService.items$.pipe(
      map((items: CartItem[]) => items.reduce((total: number, item: CartItem) => total + item.quantidade, 0))
    );
  }

  ngOnInit(): void {
    this.loadDishes();
  }

  loadDishes(): void {
    this.isLoading = true;
    this.error = null;
    this.dishService.getDishes().subscribe({
      next: (data) => {
        this.dishes = data;
        this.isLoading = false;
        console.log('Pratos carregados:', data);
      },
      error: (err) => {
        console.error('Erro ao buscar pratos:', err);
        this.error = 'Não foi possível carregar o cardápio. O backend está rodando?';
        this.isLoading = false;
      }
    });
  }

  adicionarAoCarrinho(dish: Dish): void {
    console.log('Adicionando ao carrinho:', dish.name);
    this.cartService.addItem(dish);
  }

  // REMOVIDO: O método deleteDish() foi removido daqui.
}
