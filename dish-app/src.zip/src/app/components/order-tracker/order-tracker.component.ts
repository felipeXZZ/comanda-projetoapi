import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { PedidoService, PedidoCompleto } from '../../services/pedido.service';

@Component({
  selector: 'app-order-tracker',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule // Importa o ReactiveFormsModule
  ],
  templateUrl: './order-tracker.component.html',
  styleUrls: ['./order-tracker.component.css']
})
export class OrderTrackerComponent {

  searchForm: FormGroup;
  pedidoEncontrado: PedidoCompleto | null = null;
  isLoading = false;
  error: string | null = null;

  constructor(
    private fb: FormBuilder,
    private pedidoService: PedidoService
  ) {
    this.searchForm = this.fb.group({
      pedidoId: ['', [Validators.required, Validators.pattern("^[0-9]*$")]]
    });
  }

  // Chamado quando o cliente clica em "Buscar Pedido"
  onSearch(): void {
    if (this.searchForm.invalid) {
      this.error = "Por favor, insira um ID de pedido válido.";
      return;
    }

    this.isLoading = true;
    this.error = null;
    this.pedidoEncontrado = null;

    const id = this.searchForm.value.pedidoId;

    // Chama o PedidoService (que já temos!)
    this.pedidoService.getPedidoById(id).subscribe({
      next: (pedido) => {
        this.pedidoEncontrado = pedido;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Erro ao buscar pedido:', err);
        this.error = `Pedido #${id} não encontrado. Verifique o número e tente novamente.`;
        this.isLoading = false;
      }
    });
  }
}
