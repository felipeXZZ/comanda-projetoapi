import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

// Componentes
import { SplashScreenComponent } from './components/splash-screen/splash-screen.component';
import { DishListComponent } from './components/dish-list/dish-list.component';
import { DishFormComponent } from './components/dish-form/dish-form.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { OrderTrackerComponent } from './components/order-tracker/order-tracker.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';

const routes: Routes = [
  // Splash como página inicial
  { path: '', component: SplashScreenComponent, pathMatch: 'full' },

  // Aliases semânticos do Splash:
  { path: 'cliente', redirectTo: 'cardapio', pathMatch: 'full' },
  { path: 'funcionario', redirectTo: 'admin', pathMatch: 'full' },

  // Rotas Cliente
  { path: 'cardapio', component: DishListComponent },
  { path: 'checkout', component: CheckoutComponent },
  { path: 'tracker', component: OrderTrackerComponent },

  // Rotas Admin
  { path: 'admin', component: AdminDashboardComponent },
  { path: 'add-dish', component: DishFormComponent },
  { path: 'edit-dish/:id', component: DishFormComponent },

  // 404 → volta pro Splash
  { path: '**', redirectTo: '' }
];

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    importProvidersFrom(HttpClientModule, ReactiveFormsModule)
  ]
};
